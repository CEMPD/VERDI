/*
 * Copyright (C) 2007, 2009 XStream Committers.
 * All rights reserved.
 *
 * The software in this package is published under the terms of the BSD
 * style license a copy of which has been included with this distribution in
 * the LICENSE.txt file.
 * 
 * Created on 14. September 2007 by Joerg Schaible
 */
package com.thoughtworks.xstream.tools.benchmark.xmlfriendly.model;

/**
 * Class with 100 fields containing each 5 dollars in the name.
 * 
 * @author J&ouml;rg Schaible
 */
public class A100$Fields {

    String $$$$$000;
    String $$$$$001;
    String $$$$$002;
    String $$$$$003;
    String $$$$$004;
    String $$$$$005;
    String $$$$$006;
    String $$$$$007;
    String $$$$$008;
    String $$$$$009;
    String $$$$$010;
    String $$$$$011;
    String $$$$$012;
    String $$$$$013;
    String $$$$$014;
    String $$$$$015;
    String $$$$$016;
    String $$$$$017;
    String $$$$$018;
    String $$$$$019;
    String $$$$$020;
    String $$$$$021;
    String $$$$$022;
    String $$$$$023;
    String $$$$$024;
    String $$$$$025;
    String $$$$$026;
    String $$$$$027;
    String $$$$$028;
    String $$$$$029;
    String $$$$$030;
    String $$$$$031;
    String $$$$$032;
    String $$$$$033;
    String $$$$$034;
    String $$$$$035;
    String $$$$$036;
    String $$$$$037;
    String $$$$$038;
    String $$$$$039;
    String $$$$$040;
    String $$$$$041;
    String $$$$$042;
    String $$$$$043;
    String $$$$$044;
    String $$$$$045;
    String $$$$$046;
    String $$$$$047;
    String $$$$$048;
    String $$$$$049;
    String $$$$$050;
    String $$$$$051;
    String $$$$$052;
    String $$$$$053;
    String $$$$$054;
    String $$$$$055;
    String $$$$$056;
    String $$$$$057;
    String $$$$$058;
    String $$$$$059;
    String $$$$$060;
    String $$$$$061;
    String $$$$$062;
    String $$$$$063;
    String $$$$$064;
    String $$$$$065;
    String $$$$$066;
    String $$$$$067;
    String $$$$$068;
    String $$$$$069;
    String $$$$$070;
    String $$$$$071;
    String $$$$$072;
    String $$$$$073;
    String $$$$$074;
    String $$$$$075;
    String $$$$$076;
    String $$$$$077;
    String $$$$$078;
    String $$$$$079;
    String $$$$$080;
    String $$$$$081;
    String $$$$$082;
    String $$$$$083;
    String $$$$$084;
    String $$$$$085;
    String $$$$$086;
    String $$$$$087;
    String $$$$$088;
    String $$$$$089;
    String $$$$$090;
    String $$$$$091;
    String $$$$$092;
    String $$$$$093;
    String $$$$$094;
    String $$$$$095;
    String $$$$$096;
    String $$$$$097;
    String $$$$$098;
    String $$$$$099;
}
