
/******************************************************************************
PURPOSE: shape2bin.c - Convert Shapefile (*.shp) to map_*.bin file.
NOTES:   Uses the Shapefile Library.
         Skips/ignores any additional rings after 1st ring (per polygon shape).
         Compile:
         cc -DNDEBUG -o bin/$platform/shape2bin shape2bin.c \
            -Ilib/include -Llib/$platform -lShapefile
         Run:
           shape2bin file.shp > map_file.bin
         Examples:
           bin/$platform/shape2bin NCA.shp > map_estuaries.bin
           head -4 map_estuaries.bin
HISTORY: 2009-03-25 plessel.todd@epa.gov Created.
******************************************************************************/

/*================================ INCLUDES =================================*/

#include <assert.h> /* For assert(). */
#include <stdio.h>  /* For stdout, printf(), fwrite(). */
#include <stdlib.h> /* For malloc(), free(), atof(). */
#include <string.h> /* For memset(). */
#include <limits.h> /* For ULONG_MAX. */

#include <shapefil.h> /* For SHPHandle, SHPObject, SHPOpen/Close/ReadObject()*/

/*================================== MACROS =================================*/

/* Compile-time assertion: */

#define assert_static(a) extern int unused_assert_static_[ (a) ? 1 : -1 ]

#define IMPLIES(p,c) (!(p)||(c))
#define IMPLIES_ELSE(p,c1,c2) (((p)&&(c1))||((!(p))&&(c2)))

/* Optionally include debug statements if -DDEBUGGING: */

#ifdef DEBUGGING
#define DEBUG(s) s
#else
#define DEBUG(s)
#endif

#define IN_RANGE( value, minimum , maximum ) \
  ( (value) >= (minimum) && (value) <= (maximum) )

/* Determine endian of platform: */

#if defined(__alpha) || \
    defined(__i386__) || defined(__i486__) || \
    defined(__i586__) || defined(__i686__) || \
    defined(__ia64__) || defined(__x86_64__)
#define IS_LITTLE_ENDIAN 1
#else
#define IS_LITTLE_ENDIAN 0
#endif

/* Memory allocation/deallocation: */

#define FREE( p ) ( ( (p) ? free(p) : (void) 0 ), (p) = 0 )
#define NEW( type, count ) allocate( sizeof (type), count );

#define CLOSE_SHAPEFILE( h ) ( ( (h) ? SHPClose( h ) : (void) 0), (h) = 0 )
#define CLOSE_SHAPE_OBJECT(o) (((o) ? SHPDestroyObject(o) : (void) 0), (o) = 0)

enum { LONGITUDE, LATITUDE };
enum { MINIMUM, MAXIMUM };

/*=========================== FORWARD DECLARATIONS ==========================*/

static int fileVertexCount( SHPHandle handle, int* polylines, int counts[],
                            float lonlats[] );

static SHPHandle openShapeFile( const char* fileName );

static void* allocate( size_t bytesEach, size_t count );

static int minimumItem( const int array[], int count );

static int maximumItem( const int array[], int count );

static void rotate4BytesIfLittleEndian( void* array, long long count );

/*============================= PUBLIC FUNCTIONS ============================*/



/******************************************************************************
PURPOSE: main - Main routine.
INPUTS:  int argc      Number of command-line arguments.
         char* argv[]  Command-line argument strings.
RETURNS: int 0 if successful, else 1 and failure message is printed.
******************************************************************************/

int main( int argc, char* argv[] ) {
  int ok = 0;

  assert( argc > 0 ); assert( argv ); assert( argv[ 0 ] ); assert( argv[0][0]);
  assert( argv[ argc - 1 ] );

  if ( argc != 2 ) {
    const char* const program = argv[ 0 ];
    printf( "\n\n%s - Convert Shapefile *.shp to map_*.bin file.\n", program) ;
    printf( "usage:   %s file.shp > map_file.bin\n", program );
    printf( "example: %s NCA.shp > map_estuaries.bin\n", program );
    printf( "head -4 map_estuaries.bin\n" );
    printf( "\nEmail questions and comments to: plessel.todd@epa.gov\n\n" );
  } else {
    const char* const shapeFileName = argv[ 1 ];
    SHPHandle handle = openShapeFile( shapeFileName );

    if ( handle ) {
      
      /*
       * 1st pass: count and store (in polylines) the number of non-degenerate
       * polylines and return the total number of vertices (to allocate).
       * (It would be more efficient if Shapefiles contained this information
       * in the file header so a 2nd pass would not be needed. UGLY.)
       */
      
      int polylines = 0;
      const int vertices = fileVertexCount( handle, &polylines, 0, 0 );

      if ( vertices > 1 ) {
        int* counts = NEW( int, polylines );

        if ( counts ) {
          float* lonlats = NEW( float, vertices * 2 );
          
          if ( lonlats ) {
            
            /* 2nd pass: store the counts & vertices into allocated arrays: */

            int unusedPolylines = 0;
            const int unusedVertices =
              fileVertexCount( handle, &unusedPolylines, counts, lonlats );
            
            assert( unusedVertices == vertices );
            assert( unusedPolylines == polylines );

            /* Write the 4-line ASCII header: */

            printf( "Content-type: application/octet-stream; "
                    "charset=iso-8859-1\n" ); /* For streaming into web apps.*/
            printf( "# Dimensions: polyline_count vertex_count\n" );
            printf( "%d %d\n", polylines, vertices );
            printf( "# IEEE-754/MSB 32-bit int counts[polyline_count]; "
                    "float vertices[vertex_count][2=lon,lat]:\n" );

            /* Write the binary data in 32-bit IEEE-754 (big-endian) format: */

            rotate4BytesIfLittleEndian( counts, polylines ); /* Stupid Intel. */
            rotate4BytesIfLittleEndian( lonlats, vertices * 2 );
            ok = fwrite( counts, polylines * sizeof *counts, 1, stdout) == 1;
            ok = ok &&
                 fwrite(lonlats, vertices * 2 * sizeof *lonlats, 1,stdout) == 1;
            FREE( lonlats );
          }
          
          FREE( counts );
        }
      }

      CLOSE_SHAPEFILE( handle );
    }

    if ( ! ok ) {
      perror( "Failed because" );
    }
  }

  return ! ok;
}



/*============================= PRIVATE FUNCTIONS ============================*/



/******************************************************************************
PURPOSE: fileVertexCount - Count number of polylines and vertices in the file.
INPUTS:  SHPHandle handle  File handle of input Shapefile.
OUTPUTS: int* polylines   Number of polylines.
         int counts[]     Optional: Number of vertices per polyline.
         float lonlats[]  Optional: lon-lats (interleaved) of included points.
                          lonlats[ sum( counts ) * 2 ].
RETURNS: int Number of vertices (including duplicating 1st vertex to last
             per ring) or 0 if failed.
******************************************************************************/

static int fileVertexCount( SHPHandle handle, int* polylines,
                            int counts[], float lonlats[] ) {
  int result = 0;
  assert( handle );
  assert( polylines );

  *polylines = 0;

  if ( counts ) {
    counts[ 0 ] = 0;
  }

  {
    float* ll = lonlats;
    const int shapes = handle->nRecords;
    int shape = 0;
    int polyline = 0;

    for ( shape = 0; shape < shapes; ++shape ) {
      SHPObject* object = SHPReadObject( handle, shape );

      if ( ! object ) {
        fprintf( stderr, "\a\nNull object for shape #%d\n", shape );
        result = 0;
        shape = shapes; // Stop looping.
      } else if ( /* HACK object->nSHPType == SHPP_RING && */
                  object->nParts >= 1 && object->nVertices > 1 &&
                  object->padfX && object->padfY &&
                  IN_RANGE( object->dfXMin, -180.0, 180.0 ) &&
                  IN_RANGE( object->dfXMax, -180.0, 180.0 ) &&
                  IN_RANGE( object->dfYMin,  -90.0,  90.0 ) &&
                  IN_RANGE( object->dfYMax,  -90.0,  90.0 ) ) {
        const double* const longitudes = object->padfX;
        const double* const latitudes  = object->padfY;
        const int shapeVertices = object->nVertices;
        const int parts         = object->nParts;
        int part = 0;

        DEBUG( fprintf( stderr,
                        "shape = %6d, shapeVertices = %6d, parts = %6d\n",
                        shape, shapeVertices, parts ); )

        for ( part = 0; part < parts; ++part ) {
          const int partVertexOffset = object->panPartStart[ part ];
          const int nextPartVertexOffset =
            part == parts - 1 ? shapeVertices : object->panPartStart[part + 1];
          const int partVertices = nextPartVertexOffset - partVertexOffset;

          if ( partVertices > 1 ) {
            double firstLongitude = -999.0; /* Sentinel value. */
            double firstLatitude  = -999.0;
            int validPartVertices = 0;
            int partVertex = 0;

            DEBUG( fprintf( stderr, "  part = %6d, partVertices = %6d\n",
                            part, partVertices ); )

            if ( counts ) {
              counts[ polyline ] = 0;
            }

            for ( partVertex = 0; partVertex < partVertices; ++partVertex ) {
              const int vertexIndex = partVertexOffset + partVertex;
              const double longitude = longitudes[ vertexIndex ];
              const double latitude  = latitudes[  vertexIndex ];

              if ( IN_RANGE( longitude, -180.0, 180.0 ) &&
                   IN_RANGE( latitude,   -90.0,  90.0 ) ) {
                ++validPartVertices;

                if ( lonlats ) {
                  *ll++ = longitude;
                  *ll++ = latitude;
                }

                if ( firstLongitude == -999.0 ) {
                  firstLongitude = longitude;
                  firstLatitude  = latitude;
                }
              }
            } /* End loop on this part's vertices. */

            if ( object->nSHPType == SHPP_RING ) {

              /* Duplicate 1st vertex as last to close implicit ring: */

              ++validPartVertices;

              if ( lonlats ) {
                *ll++ = firstLongitude;
                *ll++ = firstLatitude;
              }
            }

            if ( validPartVertices >= 2 ) {

              if ( counts ) {
                counts[ polyline ] += validPartVertices;
              }

              ++polyline;
              result += validPartVertices;
            }
          } /* if valid part vertex count. */
        } /* End loop on parts. */

      } /* Polyline valid. */

      CLOSE_SHAPE_OBJECT( object );

      DEBUG( fprintf( stderr,
                      "valid polylines = %6d, total valid vertices = %6d\n",
                      polyline, result ); )

    } /* End loop on file shapes. */

    *polylines = polyline;
  }

  if ( result == 0 ) {
    *polylines = 0;

    if ( counts ) {
      counts[ 0 ] = 0;
    }

    if ( lonlats ) {
      lonlats[ 0 ] = lonlats[ 1 ] = 0.0;
    }
  }

  DEBUG( fprintf( stderr, "total vertex count = %6d\n", result ); )
  DEBUG( fprintf( stderr, "*polylines = %d\n", *polylines ); )
  DEBUG( fprintf( stderr, "handle->nRecords = %d\n", handle->nRecords ); )
  assert( result >= 0 );
  assert( IMPLIES_ELSE( result > 0,
                        *polylines > 0 &&
                        IMPLIES( counts,
                                 minimumItem( counts, *polylines ) >= 2 &&
                                 maximumItem( counts, *polylines ) <= result ),
                        *polylines == 0 &&
                        IMPLIES( counts, counts[ 0 ] == 0 ) ) );
  return result;
}



/******************************************************************************
PURPOSE: openShapeFile - Open, check and return a Shapefile.
INPUTS:  const char* fileName  Name of Shapefile (*.shp) to open for reading.
RETURNS: SHPHandle  Handle to Shapefile or 0 if failed w/ failure message.
******************************************************************************/

static SHPHandle openShapeFile( const char* fileName ) {
  SHPHandle result = 0;

  assert( fileName ); assert( *fileName );
  {
    result = SHPOpen( fileName, "rb" );

    if ( result ) {
      const int polylines = result->nRecords;

      if ( ! ( result->nShapeType == SHPT_ARC ||
               result->nShapeType == SHPT_ARCZ ||
               result->nShapeType == SHPT_POLYGON ) ) {
        fprintf( stderr, "\a\nInvalid/inappropriate ShapeFile (%d)\n",
                 result->nShapeType );
        CLOSE_SHAPEFILE( result );
      } else if ( polylines < 1 ) {
        fprintf( stderr, "\n\nInvalid number of polylines (%d)\n", polylines );
        CLOSE_SHAPEFILE( result );
      }
    }
  }

  return result;
}



/******************************************************************************
PURPOSE: allocate - Implements the NEW() macro by calling malloc() to allocate
         (then zero) an array of count items, each of size bytesEach.
         If allocation fails then a message is printed to stderr.
INPUTS:  size_t sizeEach  Number of bytes per item.
         size_t count     Number of items to allocate.
RETURNS: void*  The resulting address (zeroed), or 0 if unsuccessful.
******************************************************************************/

static void* allocate( size_t bytesEach, size_t count ) {
  void* result = 0;
  assert( bytesEach > 0 ); assert( count > 0 );

  if ( bytesEach > ULONG_MAX / count || count > ULONG_MAX / bytesEach ) {
    fprintf( stderr, "\a\nCannot allocate %lu x %lu bytes ", count, bytesEach);
  } else {
    const size_t bytes = bytesEach * count;
    result = malloc( bytes );

    if ( ! result ) {
      fprintf(stderr, "\a\nCannot allocate %lu x %lu bytes ", count,bytesEach);
      perror( "because" );
    } else {
      memset( result, 0, bytes );
    }
  }

  return result;
}



/******************************************************************************
PURPOSE: minimumItem - Smallest item in array.
INPUTS:  const int array[ count ]  Items to compare.
         int count                 Number of items to compare.
RETURNS: int minimum item in array.
******************************************************************************/

static int minimumItem( const int array[], int count ) {
  int result = 0;
  int index = 0;
  assert( array ); assert( count > 0 );
  result = array[ 0 ];

  for ( index = 1; index < count; ++index ) {
    const int item = array[ index ];

    if ( item < result ) {
      result = item;
    }
  }

  return result;
}



/******************************************************************************
PURPOSE: maximumItem - Largest item in array.
INPUTS:  const int array[ count ]  Items to compare.
         int count                 Number of items to compare.
RETURNS: int maximum item in array.
******************************************************************************/

static int maximumItem( const int array[], int count ) {
  int result = 0;
  int index = 0;
  assert( array ); assert( count > 0 );
  result = array[ 0 ];

  for ( index = 1; index < count; ++index ) {
    const int item = array[ index ];

    if ( item > result ) {
      result = item;
    }
  }

  return result;
}



/******************************************************************************
PURPOSE: rotate4BytesIfLittleEndian - If little-endian platform,
         rotate 4 bytes of each item in array[ count ], otherwise no-op.
INPUTS:  void* array      Array of 4-byte words to rotate.
         long long count  Number of 4-byte words in array.
OUTPUTS: void* array      Array of big-endian 4-byte words.
******************************************************************************/

static void rotate4BytesIfLittleEndian( void* array, long long count ) {

#if IS_LITTLE_ENDIAN

  assert_static( sizeof (int) == 4 );
  int* const array4 = array;
  long long index = 0;

#pragma omp parallel for

  for ( index = 0; index < count; ++index ) {
    const int value = array4[ index ];
    const int newValue =
      ( value & 0xff000000 ) >> 24 |
      ( value & 0x00ff0000 ) >>  8 |
      ( value & 0x0000ff00 ) <<  8 |
      ( value & 0x000000ff ) << 24;
    array4[ index ] = newValue;
  }

#endif /* IS_LITTLE_ENDIAN */

}


